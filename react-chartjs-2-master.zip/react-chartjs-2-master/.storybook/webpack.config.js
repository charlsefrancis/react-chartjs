const path = require('path');

module.exports = {
  resolve: {
    alias: {
      'react-chartjs-2': path.join(__dirname, '../src'),
    },
  },
}